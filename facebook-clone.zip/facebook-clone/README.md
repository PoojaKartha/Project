# Facebook Clone 🌐

A modern, responsive Facebook clone built with vanilla HTML5, CSS3, and JavaScript. This project demonstrates proficiency in frontend web development, responsive design, and interactive UI/UX implementation.

![Facebook Clone](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)
![CSS3](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)

## 🎯 Project Overview

This project is a pixel-perfect recreation of Facebook's user interface, featuring a fully responsive design that works seamlessly across desktop, tablet, and mobile devices. Built entirely with vanilla JavaScript (no frameworks), it showcases clean code architecture and modern web development best practices.

## ✨ Features

### Core Functionality
- ✅ **Dynamic Post Creation** - Create new posts with real-time rendering
- ✅ **Interactive Like System** - Like/unlike posts with animated feedback
- ✅ **Comment System** - Add comments to posts with instant updates
- ✅ **Share Functionality** - Share post feature with counter
- ✅ **Stories Carousel** - Horizontal scrolling stories section
- ✅ **Modal Dialogs** - Create post modal with smooth animations

### UI/UX Features
- 🎨 **Responsive Navigation Bar** - Sticky header with search and icons
- 📱 **Mobile-First Design** - Fully responsive across all screen sizes
- 🌙 **CSS Grid & Flexbox** - Modern layout techniques
- ⚡ **Smooth Animations** - Transitions and hover effects
- 🎭 **Facebook Color Scheme** - Authentic color palette and styling
- ♿ **Accessibility** - Semantic HTML5 and ARIA labels

### Technical Highlights
- 🔧 **Vanilla JavaScript** - No frameworks or libraries (except Font Awesome for icons)
- 📦 **Modular Code Structure** - Separated data, logic, and presentation
- 🎯 **Event Delegation** - Efficient event handling
- 💾 **State Management** - Simple but effective state handling
- 🚀 **Performance Optimized** - Clean, efficient code

## 🛠️ Technologies Used

| Technology | Purpose |
|-----------|---------|
| HTML5 | Semantic structure and markup |
| CSS3 | Styling, animations, and responsive design |
| JavaScript (ES6+) | Interactive functionality and DOM manipulation |
| CSS Grid | Complex layout management |
| Flexbox | Flexible component layouts |
| Font Awesome | Icons |
| Google Fonts | Typography (system fonts) |

## 📂 Project Structure

```
facebook-clone/
│
├── index.html              # Main HTML file
├── css/
│   └── styles.css          # All CSS styles and responsive design
├── js/
│   ├── app.js              # Main JavaScript logic
│   └── data.js             # Sample post data
├── assets/                 # Images and media (if any)
└── README.md              # Project documentation
```

## 🚀 Getting Started

### Prerequisites
- A modern web browser (Chrome, Firefox, Safari, Edge)
- No build tools or dependencies required!

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/PoojaKartha/facebook-clone.git
   ```

2. **Navigate to the project directory**
   ```bash
   cd facebook-clone
   ```

3. **Open in browser**
   - Simply open `index.html` in your web browser
   - Or use a local server:
   ```bash
   # Using Python 3
   python -m http.server 8000
   
   # Using Node.js (http-server)
   npx http-server
   ```

4. **View the application**
   - Open `http://localhost:8000` in your browser

## 💡 How to Use

### Creating a Post
1. Click on the "What's on your mind?" input box
2. Type your post content in the modal
3. Click "Post" to publish

### Interacting with Posts
- **Like**: Click the thumbs-up icon
- **Comment**: Click comment button, type your comment, press Enter
- **Share**: Click share button

### Navigation
- Click on navigation icons to highlight them
- Scroll through stories horizontally
- Use sidebar shortcuts for quick navigation

## 🎨 Key Features Breakdown

### 1. Responsive Navigation Bar
```css
- Sticky positioning
- Three-section layout (left, center, right)
- Adaptive icons for mobile view
- Active state indicators
```

### 2. Post Creation System
```javascript
- Modal-based post creation
- Real-time text input validation
- Dynamic post rendering
- Prepend new posts to feed
```

### 3. Like & Comment System
```javascript
- Toggle like state with animation
- Real-time like counter updates
- Add comments with instant rendering
- Comment count updates
```

### 4. Responsive Design Breakpoints
```css
- Desktop: > 1200px (Three columns)
- Tablet: 992px - 1200px (Two columns)
- Mobile: < 768px (Single column)
- Small Mobile: < 576px (Optimized layout)
```

## 🌟 Code Highlights

### CSS Variables for Theming
```css
:root {
    --primary-blue: #1877f2;
    --bg-primary: #f0f2f5;
    --text-primary: #050505;
    /* Easy theme customization */
}
```

### Efficient Event Handling
```javascript
// Event delegation for dynamic posts
function attachPostEventListeners(postCard, index) {
    likeBtn.addEventListener('click', () => handleLike(index));
    commentInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') handleComment(index);
    });
}
```

### Smooth Animations
```css
@keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
}
```

## 📱 Responsive Design

The application is fully responsive and optimized for:
- ✅ Desktop (1920px and above)
- ✅ Laptop (1366px - 1920px)
- ✅ Tablet (768px - 1366px)
- ✅ Mobile (320px - 768px)

## 🔍 SEO Optimization

- ✅ Semantic HTML5 elements
- ✅ Meta tags for description and keywords
- ✅ Open Graph tags for social sharing
- ✅ Descriptive alt text for images
- ✅ ARIA labels for accessibility

## ♿ Accessibility Features

- ✅ Semantic HTML structure
- ✅ ARIA labels and roles
- ✅ Keyboard navigation support
- ✅ Proper heading hierarchy
- ✅ Color contrast compliance
- ✅ Screen reader friendly

## 🎯 Learning Outcomes

This project demonstrates:
1. **HTML5** - Semantic markup, accessibility, SEO
2. **CSS3** - Grid, Flexbox, animations, responsive design
3. **JavaScript** - DOM manipulation, event handling, state management
4. **UI/UX** - User interface design, interaction patterns
5. **Best Practices** - Clean code, modular structure, comments

## 🚧 Future Enhancements

Potential features to add:
- [ ] User authentication and profiles
- [ ] Image upload functionality
- [ ] Video posts support
- [ ] Real-time notifications
- [ ] Dark mode theme
- [ ] localStorage for persistence
- [ ] React/TypeScript conversion
- [ ] Backend integration (Node.js/Firebase)

## 🤝 Contributing

Contributions, issues, and feature requests are welcome!

1. Fork the project
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📄 License

This project is open source and available under the [MIT License](LICENSE).

## 👤 Author

**Pooja Kartha**

- GitHub: [@PoojaKartha](https://github.com/PoojaKartha)
- LinkedIn: [Pooja Kartha](https://linkedin.com/in/pooja-kartha-346491224)
- Email: karthap2002@gmail.com

## 🙏 Acknowledgments

- Font Awesome for icons
- Unsplash for sample images
- Pravatar for avatar placeholders
- Facebook for design inspiration

## 📸 Screenshots

### Desktop View
![Desktop View](screenshots/desktop.png)
*Full three-column layout with sidebar navigation*

### Mobile View
![Mobile View](screenshots/mobile.png)
*Responsive single-column layout optimized for mobile devices*

### Create Post Modal
![Create Post](screenshots/create-post.png)
*Interactive modal for creating new posts*

---

⭐ **Star this repository if you found it helpful!**

Made with ❤️ by Pooja Kartha
