// Sample post data
const postsData = [
    {
        id: 1,
        user: {
            name: "Sarah Johnson",
            avatar: "https://i.pravatar.cc/150?img=5",
            time: "2 hours ago"
        },
        content: "Just finished an amazing hike in the mountains! The view from the top was absolutely breathtaking. Nature never fails to amaze me. 🏔️ #hiking #nature #adventure",
        image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&h=500&fit=crop",
        likes: 234,
        comments: [
            {
                user: "John Doe",
                avatar: "https://i.pravatar.cc/40?img=2",
                text: "Wow! That looks incredible. Which trail did you take?"
            },
            {
                user: "Emma Davis",
                avatar: "https://i.pravatar.cc/40?img=7",
                text: "Beautiful photo! I need to go hiking more often."
            }
        ],
        shares: 12
    },
    {
        id: 2,
        user: {
            name: "Michael Chen",
            avatar: "https://i.pravatar.cc/150?img=12",
            time: "5 hours ago"
        },
        content: "Excited to announce that I've just launched my new web development portfolio! Check it out and let me know what you think. Feedback is always appreciated! 💻✨",
        image: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=800&h=500&fit=crop",
        likes: 189,
        comments: [
            {
                user: "Lisa Anderson",
                avatar: "https://i.pravatar.cc/40?img=9",
                text: "Congratulations! The design looks amazing!"
            }
        ],
        shares: 8
    },
    {
        id: 3,
        user: {
            name: "Emily Rodriguez",
            avatar: "https://i.pravatar.cc/150?img=16",
            time: "8 hours ago"
        },
        content: "Coffee and coding - the perfect Sunday morning combo! ☕👨‍💻 Working on a new project that I can't wait to share with you all. Stay tuned!",
        image: "https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=800&h=500&fit=crop",
        likes: 342,
        comments: [
            {
                user: "David Brown",
                avatar: "https://i.pravatar.cc/40?img=10",
                text: "That's the spirit! What are you working on?"
            },
            {
                user: "Chris Martinez",
                avatar: "https://i.pravatar.cc/40?img=8",
                text: "Coffee is definitely essential for coding sessions!"
            }
        ],
        shares: 5
    },
    {
        id: 4,
        user: {
            name: "Alex Thompson",
            avatar: "https://i.pravatar.cc/150?img=6",
            time: "12 hours ago"
        },
        content: "Just tried this new restaurant downtown and it was absolutely delicious! 🍕 If you're a pizza lover, you need to check out Bella Italia. Best margherita I've had in years!",
        image: "https://images.unsplash.com/photo-1513104890138-7c749659a591?w=800&h=500&fit=crop",
        likes: 156,
        comments: [
            {
                user: "Jane Smith",
                avatar: "https://i.pravatar.cc/40?img=3",
                text: "Added to my must-visit list! Thanks for the recommendation!"
            }
        ],
        shares: 3
    },
    {
        id: 5,
        user: {
            name: "Jessica Williams",
            avatar: "https://i.pravatar.cc/150?img=20",
            time: "1 day ago"
        },
        content: "Throwback to last summer's beach vacation 🏖️ Missing those sunny days and ocean waves. Can't wait for the next adventure! Where should I go next?",
        image: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop",
        likes: 412,
        comments: [
            {
                user: "Mike Johnson",
                avatar: "https://i.pravatar.cc/40?img=4",
                text: "The Maldives! You'll love it there."
            },
            {
                user: "Sarah Wilson",
                avatar: "https://i.pravatar.cc/40?img=5",
                text: "Beautiful photo! Have you considered Bali?"
            }
        ],
        shares: 15
    }
];

// Export for use in app.js
window.postsData = postsData;
