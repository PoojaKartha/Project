// ==================== STATE MANAGEMENT ====================
let posts = [...window.postsData];
let postIdCounter = posts.length + 1;

// ==================== DOM ELEMENTS ====================
const postsContainer = document.getElementById('postsContainer');
const postInput = document.getElementById('postInput');
const createPostModal = document.getElementById('createPostModal');
const modalPostText = document.getElementById('modalPostText');
const createPostBtn = document.getElementById('createPostBtn');
const closeModal = document.getElementById('closeModal');
const postOptions = document.querySelectorAll('.post-option');

// ==================== INITIALIZE APP ====================
document.addEventListener('DOMContentLoaded', () => {
    renderPosts();
    initializeEventListeners();
});

// ==================== EVENT LISTENERS ====================
function initializeEventListeners() {
    // Open modal when clicking on post input
    postInput.addEventListener('click', openCreatePostModal);
    
    // Post option buttons in main feed
    postOptions.forEach(option => {
        option.addEventListener('click', (e) => {
            e.stopPropagation();
            openCreatePostModal();
            const type = option.dataset.type;
            if (type) {
                modalPostText.placeholder = `What's on your mind about ${type}?`;
            }
        });
    });
    
    // Close modal
    closeModal.addEventListener('click', closeCreatePostModal);
    
    // Close modal when clicking outside
    createPostModal.addEventListener('click', (e) => {
        if (e.target === createPostModal) {
            closeCreatePostModal();
        }
    });
    
    // Create post button
    createPostBtn.addEventListener('click', handleCreatePost);
    
    // Enable/disable post button based on text
    modalPostText.addEventListener('input', () => {
        createPostBtn.disabled = modalPostText.value.trim() === '';
    });
    
    // Allow Enter+Shift for new line, Enter alone to post
    modalPostText.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            if (modalPostText.value.trim() !== '') {
                handleCreatePost();
            }
        }
    });
}

// ==================== MODAL FUNCTIONS ====================
function openCreatePostModal() {
    createPostModal.classList.add('active');
    modalPostText.focus();
    createPostBtn.disabled = true;
}

function closeCreatePostModal() {
    createPostModal.classList.remove('active');
    modalPostText.value = '';
    modalPostText.placeholder = "What's on your mind, Pooja?";
    createPostBtn.disabled = true;
}

// ==================== POST CREATION ====================
function handleCreatePost() {
    const content = modalPostText.value.trim();
    
    if (content === '') {
        return;
    }
    
    const newPost = {
        id: postIdCounter++,
        user: {
            name: "Pooja Kartha",
            avatar: "https://i.pravatar.cc/150?img=1",
            time: "Just now"
        },
        content: content,
        image: null,
        likes: 0,
        comments: [],
        shares: 0
    };
    
    // Add to beginning of posts array
    posts.unshift(newPost);
    
    // Re-render posts
    renderPosts();
    
    // Close modal
    closeCreatePostModal();
    
    // Scroll to top to show new post
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ==================== RENDER POSTS ====================
function renderPosts() {
    postsContainer.innerHTML = '';
    
    posts.forEach((post, index) => {
        const postCard = createPostCard(post, index);
        postsContainer.appendChild(postCard);
    });
}

function createPostCard(post, index) {
    const postCard = document.createElement('div');
    postCard.className = 'post-card';
    postCard.dataset.postId = post.id;
    
    // Format time
    const timeAgo = post.user.time;
    
    postCard.innerHTML = `
        <div class="post-header">
            <div class="post-user">
                <img src="${post.user.avatar}" alt="${post.user.name}">
                <div class="post-user-info">
                    <h4>${post.user.name}</h4>
                    <div class="post-time">
                        <span>${timeAgo}</span>
                        <span>·</span>
                        <i class="fas fa-globe-americas"></i>
                    </div>
                </div>
            </div>
            <button class="post-menu-btn" aria-label="Post options">
                <i class="fas fa-ellipsis-h"></i>
            </button>
        </div>
        
        <div class="post-content">
            <p class="post-text">${post.content}</p>
            ${post.image ? `<img src="${post.image}" alt="Post image" class="post-image">` : ''}
        </div>
        
        <div class="post-stats">
            <div class="post-likes">
                <div class="like-icon">
                    <i class="fas fa-thumbs-up"></i>
                </div>
                <span class="likes-count">${post.likes}</span>
            </div>
            <div class="post-comments-shares">
                <span class="comments-count">${post.comments.length} comments</span>
                <span>${post.shares} shares</span>
            </div>
        </div>
        
        <div class="post-actions">
            <button class="action-btn like-btn" data-index="${index}">
                <i class="far fa-thumbs-up"></i>
                <span>Like</span>
            </button>
            <button class="action-btn comment-btn" data-index="${index}">
                <i class="far fa-comment"></i>
                <span>Comment</span>
            </button>
            <button class="action-btn share-btn" data-index="${index}">
                <i class="far fa-share-square"></i>
                <span>Share</span>
            </button>
        </div>
        
        <div class="post-comments-section" id="comments-${index}">
            ${renderComments(post.comments)}
            <div class="comment-input-container">
                <img src="https://i.pravatar.cc/40?img=1" alt="Your profile">
                <input type="text" class="comment-input" placeholder="Write a comment..." data-index="${index}">
            </div>
        </div>
    `;
    
    // Add event listeners for this post
    attachPostEventListeners(postCard, index);
    
    return postCard;
}

function renderComments(comments) {
    if (!comments || comments.length === 0) {
        return '';
    }
    
    return comments.map(comment => `
        <div class="comment-item">
            <img src="${comment.avatar}" alt="${comment.user}">
            <div class="comment-content">
                <div class="comment-user">${comment.user}</div>
                <div class="comment-text">${comment.text}</div>
            </div>
        </div>
    `).join('');
}

// ==================== POST INTERACTIONS ====================
function attachPostEventListeners(postCard, index) {
    // Like button
    const likeBtn = postCard.querySelector('.like-btn');
    likeBtn.addEventListener('click', () => handleLike(index, likeBtn));
    
    // Comment button (toggle comments section)
    const commentBtn = postCard.querySelector('.comment-btn');
    const commentsSection = postCard.querySelector('.post-comments-section');
    commentBtn.addEventListener('click', () => {
        commentsSection.classList.toggle('active');
    });
    
    // Share button
    const shareBtn = postCard.querySelector('.share-btn');
    shareBtn.addEventListener('click', () => handleShare(index));
    
    // Comment input
    const commentInput = postCard.querySelector('.comment-input');
    commentInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            handleComment(index, commentInput);
        }
    });
}

function handleLike(index, likeBtn) {
    const post = posts[index];
    const likesCountSpan = likeBtn.closest('.post-card').querySelector('.likes-count');
    const likeIcon = likeBtn.querySelector('i');
    
    // Toggle like
    if (likeBtn.classList.contains('liked')) {
        // Unlike
        likeBtn.classList.remove('liked');
        likeIcon.classList.remove('fas');
        likeIcon.classList.add('far');
        post.likes = Math.max(0, post.likes - 1);
    } else {
        // Like
        likeBtn.classList.add('liked');
        likeIcon.classList.remove('far');
        likeIcon.classList.add('fas');
        post.likes += 1;
        
        // Add animation
        likeBtn.style.transform = 'scale(1.2)';
        setTimeout(() => {
            likeBtn.style.transform = 'scale(1)';
        }, 200);
    }
    
    likesCountSpan.textContent = post.likes;
}

function handleComment(index, commentInput) {
    const commentText = commentInput.value.trim();
    
    if (commentText === '') {
        return;
    }
    
    const newComment = {
        user: "Pooja Kartha",
        avatar: "https://i.pravatar.cc/40?img=1",
        text: commentText
    };
    
    posts[index].comments.push(newComment);
    
    // Update comments count
    const postCard = commentInput.closest('.post-card');
    const commentsCountSpan = postCard.querySelector('.comments-count');
    commentsCountSpan.textContent = `${posts[index].comments.length} comments`;
    
    // Re-render comments section
    const commentsSection = postCard.querySelector('.post-comments-section');
    commentsSection.innerHTML = `
        ${renderComments(posts[index].comments)}
        <div class="comment-input-container">
            <img src="https://i.pravatar.cc/40?img=1" alt="Your profile">
            <input type="text" class="comment-input" placeholder="Write a comment..." data-index="${index}">
        </div>
    `;
    
    // Re-attach event listener to new input
    const newCommentInput = commentsSection.querySelector('.comment-input');
    newCommentInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            handleComment(index, newCommentInput);
        }
    });
    
    // Clear and focus input
    newCommentInput.focus();
}

function handleShare(index) {
    posts[index].shares += 1;
    
    const shareCountSpan = document.querySelector(`[data-post-id="${posts[index].id}"] .post-comments-shares span:last-child`);
    shareCountSpan.textContent = `${posts[index].shares} shares`;
    
    // Show a simple alert (in production, this would open a share dialog)
    alert('Post shared! (In a real app, this would open a share dialog)');
}

// ==================== UTILITY FUNCTIONS ====================
function getTimeAgo(timestamp) {
    const now = new Date();
    const postTime = new Date(timestamp);
    const diffInSeconds = Math.floor((now - postTime) / 1000);
    
    if (diffInSeconds < 60) {
        return 'Just now';
    } else if (diffInSeconds < 3600) {
        const minutes = Math.floor(diffInSeconds / 60);
        return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
    } else if (diffInSeconds < 86400) {
        const hours = Math.floor(diffInSeconds / 3600);
        return `${hours} hour${hours > 1 ? 's' : ''} ago`;
    } else {
        const days = Math.floor(diffInSeconds / 86400);
        return `${days} day${days > 1 ? 's' : ''} ago`;
    }
}

// ==================== ANIMATIONS & INTERACTIONS ====================
// Add smooth scroll behavior
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Story navigation
const storiesContainer = document.querySelector('.stories-container');
if (storiesContainer) {
    let isDown = false;
    let startX;
    let scrollLeft;

    storiesContainer.addEventListener('mousedown', (e) => {
        isDown = true;
        startX = e.pageX - storiesContainer.offsetLeft;
        scrollLeft = storiesContainer.scrollLeft;
    });

    storiesContainer.addEventListener('mouseleave', () => {
        isDown = false;
    });

    storiesContainer.addEventListener('mouseup', () => {
        isDown = false;
    });

    storiesContainer.addEventListener('mousemove', (e) => {
        if (!isDown) return;
        e.preventDefault();
        const x = e.pageX - storiesContainer.offsetLeft;
        const walk = (x - startX) * 2;
        storiesContainer.scrollLeft = scrollLeft - walk;
    });
}

// ==================== CONSOLE LOG FOR DEBUGGING ====================
console.log('Facebook Clone loaded successfully!');
console.log(`${posts.length} posts rendered`);
